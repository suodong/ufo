<style scope="scope">

#a{
width: 100%;
height: 200px;
background:url(../assets/1.jpg) no-repeat center 0;
}
.a1{
  width:100%;height:40px;
  background: #333;
  margin-top:-82px;
}
.a2{
  width:1226px;height:40px;
/*  background: pink;*/
  font-size: 12px;
  color: #b0b0b0;
  margin-right: auto;
    margin-left: auto;
}
.a3{
  width:670px;height:40px;
 /* background: orange;*/
  line-height: 40px;
      float: left;
}
.a3 a{
  color: #b0b0b0;
}
.a3 a:hover{
  color: #ffffff;
}
.a4{
  margin: 0 .5em;
  color: #424242;
}
.a5{
  width:120px;height: 40px;
/*  background: red;*/
  float: right;
  margin-left: 15px;
}
.a5 a:hover{
  color:orange;
  background: #ffffff;
}
.a5 a{
  width:120px;height:40px;
  line-height: 40px;
  display: block;
  text-align: center;
   color: #b0b0b0;
  background: #424242;
}
.a6{

   width: 148px;height: 40px;
   float: right;
   line-height: 40px;
/*   background: green;*/
}
.a6 a{
  width:24px;height:40px;
  padding: 0 2px;
  text-align: center;
  color: #b0b0b0;
}
.a6 a:hover{
  color:#ffffff;
}
.b{
  width:100%;height:100px;
/*  background: red;*/
}
.b1{
  width:1226px;height: 100px;
/*  background: orange;*/
    margin-right: auto;
    margin-left: auto;
}
.b2{
  width:62px;height:55px;
  background: url(../assets/1.png) no-repeat 50% 50%;
  float: left;
  margin-top: 22px;
}
.b3{
  width:850px;height:100px;
/*  background: pink;*/
  float: left;

}
.b4{
  width:820px;height: 88px;
  float: left;
/*  background: purple;*/
  padding: 12px 0 0 30px;
  font-size: 16px;
}
#b5{
  width:127px;height: 88px;
/*  background: red;*/
  float: left;
  padding-right: 15px;
}
.b6{
  width:84px;height: 88px;
  float: left; 
   margin-top: 30px;
}
.b6 a{
  width:64px;height:24px;
  display: block;
/*  background:pink;*/
  margin-left: 10px;
  color: #333;

}
.b7 {
  width:45px;height: 24px;
  float: left; 
  margin-top: 30px;
  margin-left: 10px;

}
.b7 a{
    width:45px;height:24px;
    display: block;
    color: #333;
  
}
.b8{
    width:296px;height:50px;
/*    background: blue;*/
    float: right;
    margin-top: 25px;
    position: relative;
}
.cc{
    width:223px;height: 46px;
    padding: 0 10px;
    border: 1px solid #e0e0e0;
    font-size: 14px;
    line-height: 48px;
    position: absolute;
    top: 0;
    right: 51px;
}
.ccc{
  width:46px;height:46px;
  border: 1px solid #e0e0e0;
  margin-right: 30px;
  position: absolute;
  right: 0;top: 0;    
}
.f{
  width:1230px;height:170px;
  position: absolute;
  top:740px;left:60px;


}
.f1{
  width:234px;height: 170px;
  background: orange;
  float: left;
}
.f2{
  width:228px;height:164px;
  padding: 3px;
    font-size: 12px;
    text-align: center;
    background: #5f5750;
}
.f3{
  width:70px;height:82px;
    position: relative;
    float: left;
    padding: 0 3px;

}
.f3 a{
  width:70px;height:46px;
  display: block;
  line-height: 46px;
   padding-top: 18px;
   text-align: center;
  color: rgba(255,255,255,0.7);
  font-size: 12px;

}
.f4{
  width:978px;height:170px;
  float: left;
   margin-left: 16px;
     display:flex;
 justify-content: space-between ;

}
.f5{
  width:316px;height: 170px;
}
.f5:hover{
 box-shadow: 12px 12px 30px #eee;
}
.f5 img{
  width:316px;height: 170px;
}
.f6{
  width:1230px;height: 438px;
  position: absolute;
  top:940px;left:57px;
}
.f7{
  width:1230px;height:58px;

}
.f7 h2{
  width:1230px;height:58px;
  font-size: 22px; 
  line-height: 58px;
  color: #333;
}
.f8{
  width:1230px;height:340px;
  padding-bottom: 40px;
}
.f9{
  width:1230px;height: 340px;

}
.g{
  width:234px;height: 300px;
  border-top-color: #ffac13;
  padding-top: 39px;
  border-top-style: solid;
  text-align: center;
  background: #fafafa;
  border-top-width: 1px;
  float: left;
  margin-right: 12px;
  background: #fafafa;
}
.g1{
    width:234px;height: 300px;
  border-top-color: #83c44e;
  padding-top: 39px;
  border-top-style: solid;
  text-align: center;
  background:#fafafa;
  border-top-width: 1px;
  margin-right: 12px;
    float: left;
      background: #fafafa;

}
.g2{
    width:234px;height: 300px;
  border-top-color: #2196f3;
  padding-top: 39px;
  border-top-style: solid;
  text-align: center;
  background:#fafafa;
  border-top-width: 1px;
  margin-right: 12px;
    float: left;
      background: #fafafa;
}
.g3{
    width:234px;height: 300px;
  border-top-color: #e53935;
  padding-top: 39px;
  border-top-style: solid;
  text-align: center;
  background:#fafafa;
  border-top-width: 1px;
  margin-right: 12px;
  float: left;
  background: #fafafa;
}
.g4{
    width:234px;height: 300px;
  border-top-color: #00c0a5;
  padding-top: 39px;
  border-top-style: solid;
  text-align: center;
  background:#fafafa;
  border-top-width: 1px;
  margin-right: 12px;
    float: left;
      background: #fafafa;
}
.t a{
  width:160px;height:166px;
  display: block;
  margin: 0 auto 22px;
}
.t a img{
  width:160px;height: 166px;
}
.t h3{
  width:194px;height:21px;
  display: block;
  margin: 0 20px 3px;
    font-size: 14px;
    color: #212121;
}
.t span{
  width: 194px;height: 18px;
    display: block;
  margin: 0 20px 12px;
    font-size: 12px;
    color: #b0b0b0;
}
.t p{
  width:234px;height: 21px;
  display: block;
  color: #ff6709;
}
</style>
<template>
  <div>
      <div id="a"></div>
        <div class="a1">
           <div class="a2">
             <div class="a3">
               <a href="">小米商城</a>
               <span class="a4">|</span>
                 <a href="">MIUI</a>
               <span class="a4">|</span>
                 <a href="">米聊</a>
               <span class="a4">|</span>
                 <a href="">游戏</a>
               <span class="a4">|</span>
                 <a href="">多看阅读</a>
               <span class="a4">|</span>
                 <a href="">云服务</a>
               <span class="a4">|</span>
                 <a href="">金融</a>
               <span class="a4">|</span>
                 <a href="">米币</a>
               <span class="a4">|</span>
                 <a href="">小米商城手机版</a>
               <span class="a4">|</span>
                 <a href="">问题反馈</a>
               <span class="a4">|</span>
                <a href="">SelectRegion</a>
             
             </div>
             <div class="a5">
               <a href="">
                购物车（0）
               </a>
             </div>
             <div class="a6">
               <a href="">登录</a>
               <span class="a4">|</span>
               <a href="">注册</a>
               <span class="a4">|</span>
               <a href="">消息通知</a>
          
             </div>
           </div>
      </div>
      <div class="b">
        <div class="b1">
          <div class="b2"></div>
          <div class="b3">
            <ul class="b4">
               <li id="b5"></li>
               <li class="b6" @click="aaa"><a href="javascript:;">小米手机</a></li>
               <li class="b7" @click="bbb"><a href="javascript:;">红米</a></li>
               <li class="b6" @click="ccc"><a href="javascript:;">笔记本</a></li>
               <li class="b7" @click="ddd"><a href="javascript:;">电视</a></li>
               <li class="b7" @click="eee"><a href="javascript:;">盒子</a></li>
               <li class="b7"><a href="javascript:;">新品</a></li>
               <li class="b6"><a href="javascript:;">路由器</a></li>
               <li class="b6"><a href="javascript:;">智能硬件</a></li>
               <li class="b7"><a href="javascript:;">服务</a></li>
               <li class="b7"><a href="javascript:;">社区</a></li>
            </ul>

          </div>
          <div class="b8">
            <input class="cc"type="" name="">
            <input class="ccc"type="" name="">
          </div>
        </div>
      </div>
      <div class="f">
        <div class="f1">
          <ul class="f2">
            <li class="f3"><a href="">选购手机</a></li>
            <li class="f3"><a href="">企业团购</a></li>
            <li class="f3"><a href="">F码通道</a></li>
            <li class="f3"><a href="">米粉卡</a></li>
            <li class="f3"><a href="">以旧换新</a></li>
            <li class="f3"><a href="">话费充值</a></li>
          </ul>
        </div>    
        <div class="f4">
          <div class="f5"><img src="../assets/8.jpg"></div>
          <div class="f5"><img src="../assets/9.jpg"></div>
          <div class="f5"><img src="../assets/10.jpg"></div>
        </div> 
        
      </div>
      <div class="f6">
        <div class="f7">
          <h2>小米明星单品</h2>
        </div>
        <div class="f8">
          <div class="f9">
             <div class="g t"><a href="">
               <img src="../assets/2.png"></a>
                  <h3>红米Note 4X 浅蓝色</h3>
                  <span>金属机身,4100mAh 超长续航</span>
                  <p>999元起</p>
                </div>
             <div class="g1 t"><a href=""><img src="../assets/3.png"></a>
                   <h3>红米Note 4X </h3>
                  <span>4100mAh超长续航，多彩金属</span>
                  <p>999元起</p>
             </div>
             <div class="g2 t"><a href=""><img src="../assets/4.png"></a>
                 <h3>红米4X</h3>
                  <span>4100mAh超长续航，8 核处理器</span>
                  <p>699元起</p></div>
             <div class="g3 t"><a href=""><img src="../assets/5.png"></a>
                 <h3>小米电视4A 43英寸 标准版</h3>
                  <span>全高清HDR 四核高性能处理器</span>
                  <p>1899元起</p></div>
             <div class="g4 t"><a href=""><img src="../assets/6.png"></a>
                 <h3>小米笔记本</h3>
                  <span>更轻更薄，像杂志一样随身携带</span>
                  <p>3599元起</p></div>
          </div>
        </div>
      </div>
  </div>   
</template>

<script>
// import publics from'../../components/publics'
export default {
  name: 'admin', 
  data () {
    return {

    }
  },
  methods:{
     aaa(){
      this.$router.push({
        name:'a'
      })
     },
    bbb(){
      this.$router.push({
        name:'b'
      })
     },
    ccc(){
      this.$router.push({
        name:'c'
      })
     },
    ddd(){
      this.$router.push({
        name:'d'
      })    
     },
   eee(){
      this.$router.push({
        name:'e'
      })
     }
  },
  watch:{
     
  },
  mounted(){

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
